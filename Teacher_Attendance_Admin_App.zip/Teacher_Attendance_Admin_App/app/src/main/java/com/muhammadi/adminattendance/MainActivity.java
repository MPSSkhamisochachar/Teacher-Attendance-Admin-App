package com.muhammadi.adminattendance;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String ADMIN_URL =
        "https://script.google.com/macros/s/AKfycbwejImpn0vJFW7yM5dSifqECxxNFsgIZvhT10OVkz_1za8Ll4KFeIuiSfSOEPfQ2eD5pw/exec?action=admin";

    private static final int FILE_REQUEST = 9001;
    private static final int PERMISSION_REQUEST = 9002;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        requestRequiredPermissions();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(true);

        webView.setWebViewClient(new SecureWebViewClient());
        webView.setWebChromeClient(new SecureChromeClient());

        webView.loadUrl(ADMIN_URL);
    }

    private void requestRequiredPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[] {
                Manifest.permission.CAMERA,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            }, PERMISSION_REQUEST);
        }
    }

    private boolean allowedHost(Uri uri) {
        if (uri == null) return false;
        String host = uri.getHost();
        if (host == null) return false;

        return host.equals("script.google.com")
                || host.endsWith(".googleusercontent.com")
                || host.equals("googleusercontent.com")
                || host.equals("accounts.google.com")
                || host.equals("cdn.jsdelivr.net")
                || host.equals("justadudewhohacks.github.io");
    }

    private class SecureWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (allowedHost(uri)) {
                return false;
            }
            Toast.makeText(MainActivity.this,
                    "External website blocked for security.",
                    Toast.LENGTH_SHORT).show();
            return true;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Uri uri = Uri.parse(url);
            if (allowedHost(uri)) return false;
            Toast.makeText(MainActivity.this,
                    "External website blocked for security.",
                    Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    private class SecureChromeClient extends WebChromeClient {
        @Override
        public void onGeolocationPermissionsShowPrompt(
                String origin,
                GeolocationPermissions.Callback callback) {

            if (origin != null && origin.startsWith("https://script.google.com")) {
                callback.invoke(origin, true, false);
            } else {
                callback.invoke(origin, false, false);
            }
        }

        @Override
        public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> callback,
                FileChooserParams params) {

            if (fileCallback != null) {
                fileCallback.onReceiveValue(null);
            }

            fileCallback = callback;

            Intent intent = params.createIntent();
            intent.addCategory(Intent.CATEGORY_OPENABLE);

            try {
                startActivityForResult(intent, FILE_REQUEST);
                return true;
            } catch (Exception e) {
                fileCallback = null;
                Toast.makeText(MainActivity.this,
                        "Camera/photo chooser could not open.",
                        Toast.LENGTH_SHORT).show();
                return false;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_REQUEST && fileCallback != null) {
            Uri[] results = null;

            if (resultCode == Activity.RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[] { uri };
            }

            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
