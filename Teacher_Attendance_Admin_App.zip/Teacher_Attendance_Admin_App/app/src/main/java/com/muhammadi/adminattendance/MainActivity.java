package com.muhammadi.adminattendance;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String ADMIN_URL =
            "https://script.google.com/macros/s/AKfycbwejImpn0vJFW7yM5dSifqECxxNFsgIZvhT10OVkz_1za8Ll4KFeIuiSfSOEPfQ2eD5pw/exec?action=admin";

    private static final int CAMERA_REQUEST = 7001;
    private static final int PERMISSION_REQUEST = 7002;

    private WebView webView;

    private ValueCallback<Uri[]> fileCallback;

    private Uri cameraUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        setupWebView();

        requestRequiredPermissions();

        webView.loadUrl(ADMIN_URL);
    }

    private void setupWebView() {

        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);

        settings.setDatabaseEnabled(false);

        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        settings.setSupportMultipleWindows(false);

        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        settings.setMediaPlaybackRequiresUserGesture(true);

        settings.setMixedContentMode(
                WebSettings.MIXED_CONTENT_NEVER_ALLOW
        );

        settings.setGeolocationEnabled(true);

        webView.setWebViewClient(new SecureWebViewClient());

        webView.setWebChromeClient(new SecureChromeClient());
    }

    private void requestRequiredPermissions() {

        if (android.os.Build.VERSION.SDK_INT >= 23) {

            requestPermissions(
                    new String[]{
                            Manifest.permission.CAMERA,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    },
                    PERMISSION_REQUEST
            );
        }
    }

    private boolean allowedHost(Uri uri) {

        if (uri == null) {
            return false;
        }

        String host = uri.getHost();

        if (host == null) {
            return false;
        }

        return host.equals("script.google.com")
                || host.endsWith(".googleusercontent.com")
                || host.equals("googleusercontent.com")
                || host.equals("accounts.google.com")
                || host.equals("cdn.jsdelivr.net")
                || host.equals("justadudewhohacks.github.io");
    }

    private class SecureWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(
                WebView view,
                WebResourceRequest request) {

            Uri uri = request.getUrl();

            if (allowedHost(uri)) {
                return false;
            }

            Toast.makeText(
                    MainActivity.this,
                    "External website blocked for security.",
                    Toast.LENGTH_SHORT
            ).show();

            return true;
        }

        @Override
        public boolean shouldOverrideUrlLoading(
                WebView view,
                String url) {

            Uri uri = Uri.parse(url);

            if (allowedHost(uri)) {
                return false;
            }

            Toast.makeText(
                    MainActivity.this,
                    "External website blocked for security.",
                    Toast.LENGTH_SHORT
            ).show();

            return true;
        }
    }

    private class SecureChromeClient extends WebChromeClient {

        @Override
        public void onGeolocationPermissionsShowPrompt(
                String origin,
                GeolocationPermissions.Callback callback) {

            if (origin != null
                    && origin.startsWith("https://script.google.com")) {

                callback.invoke(origin, true, false);

            } else {

                callback.invoke(origin, false, false);
            }
        }

        @Override
        public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> callback,
                FileChooserParams params) {

            // Cancel any previous request
            if (fileCallback != null) {
                fileCallback.onReceiveValue(null);
            }

            fileCallback = callback;

            // NEVER open Android Gallery/File Picker.
            // Always open the phone camera.
            openCamera();

            return true;
        }
    }

    private void openCamera() {

        if (android.os.Build.VERSION.SDK_INT >= 23) {

            if (checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(
                        this,
                        "Camera permission is required.",
                        Toast.LENGTH_LONG
                ).show();

                finishFileRequest(null);

                return;
            }
        }

        Intent cameraIntent =
                new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (cameraIntent.resolveActivity(
                getPackageManager()) == null) {

            Toast.makeText(
                    this,
                    "No camera application was found.",
                    Toast.LENGTH_LONG
            ).show();

            finishFileRequest(null);

            return;
        }

        try {

            File photoFile = createImageFile();

            cameraUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    photoFile
            );

            cameraIntent.putExtra(
                    MediaStore.EXTRA_OUTPUT,
                    cameraUri
            );

            cameraIntent.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            );

            // Give camera application permission to use the URI.
            cameraIntent.setClipData(
                    android.content.ClipData.newRawUri(
                            "teacher_face",
                            cameraUri
                    )
            );

            startActivityForResult(
                    cameraIntent,
                    CAMERA_REQUEST
            );

        } catch (Exception e) {

            cameraUri = null;

            Toast.makeText(
                    this,
                    "Camera could not be started.",
                    Toast.LENGTH_LONG
            ).show();

            finishFileRequest(null);
        }
    }

    private File createImageFile() throws IOException {

        String timeStamp =
                new SimpleDateFormat(
                        "yyyyMMdd_HHmmss",
                        Locale.getDefault()
                ).format(new Date());

        String fileName =
                "TEACHER_FACE_" + timeStamp + "_";

        File storageDir =
                getExternalFilesDir(
                        Environment.DIRECTORY_PICTURES
                );

        if (storageDir == null) {
            throw new IOException(
                    "Picture storage unavailable."
            );
        }

        if (!storageDir.exists()) {

            if (!storageDir.mkdirs()) {
                throw new IOException(
                        "Could not create picture folder."
                );
            }
        }

        return File.createTempFile(
                fileName,
                ".jpg",
                storageDir
        );
    }

    private void finishFileRequest(@Nullable Uri uri) {

        if (fileCallback == null) {
            return;
        }

        if (uri != null) {

            fileCallback.onReceiveValue(
                    new Uri[]{uri}
            );

        } else {

            fileCallback.onReceiveValue(null);
        }

        fileCallback = null;
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            @Nullable Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (requestCode == CAMERA_REQUEST) {

            if (resultCode == Activity.RESULT_OK
                    && cameraUri != null) {

                // Return captured camera image to WebView.
                finishFileRequest(cameraUri);

            } else {

                // User cancelled camera.
                finishFileRequest(null);
            }

            cameraUri = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == PERMISSION_REQUEST) {

            if (grantResults.length > 0
                    && grantResults[0]
                    != PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(
                        this,
                        "Camera permission is required for face enrollment.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    @Override
    public void onBackPressed() {

        if (webView != null
                && webView.canGoBack()) {

            webView.goBack();

        } else {

            super.onBackPressed();
        }
    }
}
