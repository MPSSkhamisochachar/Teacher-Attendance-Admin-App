# Teacher Attendance Admin App

Android WebView wrapper for the existing Google Apps Script Admin page.

Admin URL is embedded in MainActivity.java.

Security included in this APK:
- HTTPS only / cleartext traffic disabled
- External website navigation blocked
- JavaScript + DOM storage enabled only because the Apps Script page needs them
- Camera/photo chooser support for face enrollment
- Geolocation permission support
- Android backup disabled
- Admin URL is fixed in the app

IMPORTANT:
The APK alone cannot make the Google Apps Script backend fully secure. The strongest security must be applied in Code.gs:
1. Admin operations must require a server-side authenticated session/token, not only a UI PIN.
2. Teacher attendance functions should never accept arbitrary teacher IDs without server validation.
3. Keep the Apps Script deployment restricted to the intended admin Google account if possible.
4. Do not store secrets in the APK; APKs can be reverse engineered.

This project is ready to build with GitHub Actions.
